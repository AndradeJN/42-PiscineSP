#comportamento esperado
Aparecer o computador que estou logado no intra
#comportamento atual
Está aparecendo "Unavailable"
Posição: c3r13p2